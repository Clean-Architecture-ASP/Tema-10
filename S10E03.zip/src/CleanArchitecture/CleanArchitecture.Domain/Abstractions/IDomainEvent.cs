using MediatR;

namespace CleaArchitecture.Domain.Abstractions;

public interface IDomainEvent : INotification
{
    
}
namespace CleaArchitecture.Domain.Users;

public record Email(string Value);
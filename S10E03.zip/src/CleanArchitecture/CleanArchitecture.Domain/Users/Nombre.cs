namespace CleaArchitecture.Domain.Users;

public record Nombre(string Value);
namespace CleaArchitecture.Domain.Vehiculos;

public record Modelo(string Value);